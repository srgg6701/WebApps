<?php
/**
 * @version     2.1.0
 * @package     com_collector1
 * @copyright   Copyright (C) webapps 2012. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      srgg <srgg67@gmail.com> - http://www.facebook.com/srgg67
 */

// no direct access
defined('_JEXEC') or die;
?>

<?php if( $this->item ) : ?>

    <div class="item_fields">
        
        <ul class="fields_list">

        
        
                    <li><?php echo 'id'; ?>: 
                    <?php echo $this->item->id; ?></li>

        
        
                    <li><?php echo 'precustomers_id'; ?>: 
                    <?php echo $this->item->precustomers_id; ?></li>

        
        
                    <li><?php echo 'type'; ?>: 
                    <?php echo $this->item->type; ?></li>

        
        
                    <li><?php echo 'native_ids'; ?>: 
                    <?php echo $this->item->native_ids; ?></li>

        

        </ul>
        
    </div>

<?php endif; ?>