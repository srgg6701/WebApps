<?php
/**
 * @version     1.3.0
 * @package     com_collector1
 * @copyright   Copyright (C) 2012. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Created by com_combuilder - http://www.notwebdesign.com
 */

// No direct access
defined('_JEXEC') or die;

/**
 * Collector1 helper.
 */
class Collector1Helper
{
	/**
	 * Configure the Linkbar.
	 */
	public static function addSubmenu($vName = '')
	{

		JSubMenuHelper::addEntry(
			JText::_('COM_COLLECTOR1_TITLE_L_CUSTOMERS'),
			'index.php?option=com_collector1&view=l_customers',
			$vName == 'l_customers'
		);
		JSubMenuHelper::addEntry(
			JText::_('COM_COLLECTOR1_TITLE_L_CUSTOMERS_PAID'),
			'index.php?option=com_collector1&view=l_customers_paid',
			$vName == 'l_customers_paid'
		);
		JSubMenuHelper::addEntry(
			JText::_('COM_COLLECTOR1_TITLE_L_CUSTOMER_SITE_OPTIONS'),
			'index.php?option=com_collector1&view=l_customer_site_options',
			$vName == 'l_customer_site_options'
		);
		JSubMenuHelper::addEntry(
			JText::_('COM_COLLECTOR1_TITLE_L_ENGINES_ALL'),
			'index.php?option=com_collector1&view=l_engines_all',
			$vName == 'l_engines_all'
		);
		JSubMenuHelper::addEntry(
			JText::_('COM_COLLECTOR1_TITLE_L_ENGINES_RU'),
			'index.php?option=com_collector1&view=l_engines_ru',
			$vName == 'l_engines_ru'
		);
		JSubMenuHelper::addEntry(
			JText::_('COM_COLLECTOR1_TITLE_L_SITE_OPTIONS'),
			'index.php?option=com_collector1&view=l_site_options',
			$vName == 'l_site_options'
		);
		JSubMenuHelper::addEntry(
			JText::_('COM_COLLECTOR1_TITLE_L_SITE_OPTIONS_TYPES'),
			'index.php?option=com_collector1&view=l_site_options_types',
			$vName == 'l_site_options_types'
		);
		JSubMenuHelper::addEntry(
			JText::_('COM_COLLECTOR1_TITLE_L_SITE_TYPES'),
			'index.php?option=com_collector1&view=l_site_types',
			$vName == 'l_site_types'
		);
		JSubMenuHelper::addEntry(
			JText::_('COM_COLLECTOR1_TITLE_L_OPTIONS_BEYOND_SIDES'),
			'index.php?option=com_collector1&view=l_options_beyond_sides',
			$vName == 'l_options_beyond_sides'
		);
		JSubMenuHelper::addEntry(
			JText::_('COM_COLLECTOR1_TITLE_L_SITE_OPTIONS_PARTIAL'),
			'index.php?option=com_collector1&view=l_site_options_partial',
			$vName == 'l_site_options_partial'
		);

	}

	/**
	 * Gets a list of the actions that can be performed.
	 *
	 * @return	JObject
	 * @since	1.6
	 */
	public static function getActions()
	{
		$user	= JFactory::getUser();
		$result	= new JObject;

		$assetName = 'com_collector1';

		$actions = array(
			'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
		);

		foreach ($actions as $action) {
			$result->set($action,	$user->authorise($action, $assetName));
		}

		return $result;
	}
}
