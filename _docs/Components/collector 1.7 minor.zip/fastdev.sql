-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 20, 2012 at 10:48 PM
-- Server version: 5.1.40
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fastdev`
--

-- --------------------------------------------------------

--
-- Table structure for table `dnior_webapps_customers`
--

CREATE TABLE IF NOT EXISTS `dnior_webapps_customers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dnior_users_id` int(11) unsigned NOT NULL,
  `surname` varchar(45) NOT NULL COMMENT 'Фамилия',
  `middle_name` varchar(45) NOT NULL COMMENT 'Отчество',
  `sex` tinyint(4) NOT NULL,
  `birthday` date NOT NULL,
  `work_phone` varchar(45) NOT NULL,
  `mobila` varchar(45) NOT NULL,
  `company_name` varchar(45) NOT NULL,
  `city` varchar(45) NOT NULL,
  `region` varchar(45) NOT NULL,
  `zip_code` varchar(45) NOT NULL,
  `ordering` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dnior_users_id` (`dnior_users_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Заказчики, как реальные, так и потенциальные' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `dnior_webapps_customers`
--


-- --------------------------------------------------------

--
-- Table structure for table `dnior_webapps_customers_paid`
--

CREATE TABLE IF NOT EXISTS `dnior_webapps_customers_paid` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dnior_customers_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dnior_customers_id` (`dnior_customers_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Клиенты, оплачивавшие услуги' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `dnior_webapps_customers_paid`
--


-- --------------------------------------------------------

--
-- Table structure for table `dnior_webapps_customer_site_options`
--

CREATE TABLE IF NOT EXISTS `dnior_webapps_customer_site_options` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `site_type_id` int(11) NOT NULL,
  `engine_type_choice_id` tinyint(4) NOT NULL,
  `engines_ids` text NOT NULL,
  `options_array` text NOT NULL COMMENT 'Массив выбранных опий и разделов сайта',
  `xtra` text NOT NULL COMMENT 'Дополнительные пожелания',
  `ordering` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `site_type_id` (`site_type_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Выбранные заказчиком опции сайта' AUTO_INCREMENT=13 ;

--
-- Dumping data for table `dnior_webapps_customer_site_options`
--

INSERT INTO `dnior_webapps_customer_site_options` (`id`, `customer_id`, `site_type_id`, `engine_type_choice_id`, `engines_ids`, `options_array`, `xtra`, `ordering`, `checked_out`, `checked_out_time`) VALUES
(7, 43, 2, 3, '15,33,42', 'a:14:{i:11;a:1:{i:0;s:6:"public";}i:12;a:2:{i:0;s:6:"public";i:1;s:5:"admin";}i:17;a:2:{i:0;s:6:"public";i:1;s:5:"admin";}i:14;a:1:{i:0;s:6:"public";}i:9;a:1:{i:0;s:6:"public";}i:19;a:2:{i:0;s:6:"public";i:1;s:4:"user";}i:10;a:3:{i:0;s:6:"public";i:1;s:5:"admin";i:2;s:4:"user";}i:15;a:2:{i:0;s:6:"public";i:1;s:4:"user";}i:13;a:3:{i:0;s:6:"public";i:1;s:5:"admin";i:2;s:4:"user";}i:16;a:2:{i:0;s:6:"public";i:1;s:4:"user";}i:18;a:2:{i:0;s:6:"public";i:1;s:4:"user";}i:21;a:1:{i:0;s:6:"public";}i:23;a:1:{i:0;s:6:"public";}i:22;a:1:{i:0;s:6:"public";}}', '', 6, 0, '0000-00-00 00:00:00'),
(8, 43, 1, 0, '', 'a:3:{i:4;a:1:{i:0;s:6:"public";}i:5;a:1:{i:0;s:6:"public";}i:21;a:1:{i:0;s:6:"public";}}', '', 2, 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `dnior_webapps_engines_all`
--

CREATE TABLE IF NOT EXISTS `dnior_webapps_engines_all` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `free` tinyint(4) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Список всех CMS на англ.' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `dnior_webapps_engines_all`
--


-- --------------------------------------------------------

--
-- Table structure for table `dnior_webapps_engines_ru`
--

CREATE TABLE IF NOT EXISTS `dnior_webapps_engines_ru` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `engine_id` int(11) NOT NULL COMMENT 'dnior_engines_all.id',
  `name_ru` varchar(45) NOT NULL,
  `ordering` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `engine_id` (`engine_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Список CMS, название которых может быть на русском' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `dnior_webapps_engines_ru`
--


-- --------------------------------------------------------

--
-- Table structure for table `dnior_webapps_precustomers`
--

CREATE TABLE IF NOT EXISTS `dnior_webapps_precustomers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `skype` varchar(45) NOT NULL,
  `collections_ids` text NOT NULL,
  `ordering` int(11) DEFAULT NULL,
  `state` tinyint(4) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Таблица предзаказчиков - коллекции созданы, субъекты пока не' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `dnior_webapps_precustomers`
--


-- --------------------------------------------------------

--
-- Table structure for table `dnior_webapps_site_options`
--

CREATE TABLE IF NOT EXISTS `dnior_webapps_site_options` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_ru` varchar(45) NOT NULL,
  `name_en` varchar(45) NOT NULL,
  `option_stat` tinyint(4) NOT NULL COMMENT 'Включена/выключена',
  `ordering` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Все доступные опции для сайта' AUTO_INCREMENT=25 ;

--
-- Dumping data for table `dnior_webapps_site_options`
--

INSERT INTO `dnior_webapps_site_options` (`id`, `name_ru`, `name_en`, `option_stat`, `ordering`, `checked_out`, `checked_out_time`) VALUES
(1, 'Корзина', 'Cart', 1, NULL, NULL, NULL),
(2, 'SMS-информирование', 'SMS-messages', 1, NULL, NULL, NULL),
(3, 'Запросы актуальности заказа', 'Purshase reminders', 1, NULL, NULL, NULL),
(4, 'Карточкой', 'Card', 1, NULL, NULL, NULL),
(5, 'Яндекс.деньги', '', 1, NULL, NULL, NULL),
(6, 'Webmoney', '', 1, NULL, NULL, NULL),
(7, 'PayPal', 'PayPal', 1, NULL, NULL, NULL),
(8, 'Платёжный шлюз', 'Payment gateway', 1, NULL, NULL, NULL),
(9, 'Карта сайта', 'Site map', 1, NULL, NULL, NULL),
(10, 'Поиск', 'Site search', 1, NULL, NULL, NULL),
(11, 'RSS', 'RSS', 1, NULL, NULL, NULL),
(12, 'Архив материалов', 'Stuff archive', 1, NULL, NULL, NULL),
(13, 'Страница не найдена', 'Page not found', 1, NULL, NULL, NULL),
(14, 'Добавить статью', 'Add article', 1, NULL, NULL, NULL),
(15, 'Рейтинг статьи', 'Article ranking', 1, NULL, NULL, NULL),
(16, 'Форум', 'Forum', 1, NULL, NULL, NULL),
(17, 'Блог', 'Blog', 1, NULL, NULL, NULL),
(18, 'Фотогалерея', 'Photo gallery', 1, NULL, NULL, NULL),
(19, 'Опросы', 'Polls', 1, NULL, NULL, NULL),
(20, 'Облако тегов', 'Tags cloud', 1, NULL, NULL, NULL),
(21, 'Like (нравится)', 'Like button', 1, NULL, NULL, NULL),
(22, 'Добавить в друзья', 'Make friend', 1, NULL, NULL, NULL),
(23, 'RSS в социальной сети', 'RSS for social', 1, NULL, NULL, NULL),
(24, 'Дополнительно', 'Extra options', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dnior_webapps_site_options_beyond_sides`
--

CREATE TABLE IF NOT EXISTS `dnior_webapps_site_options_beyond_sides` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `site_side` varchar(20) NOT NULL,
  `name_ru` varchar(20) NOT NULL,
  `site_options_beyond_side` text NOT NULL COMMENT 'id id опций сайта, отсутствующих в разделе [site_side]',
  `ordering` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Опции, присутствующие не во всех разделах сайта' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `dnior_webapps_site_options_beyond_sides`
--

INSERT INTO `dnior_webapps_site_options_beyond_sides` (`id`, `site_side`, `name_ru`, `site_options_beyond_side`, `ordering`, `checked_out`, `checked_out_time`) VALUES
(1, 'public', 'Публичный', '2,3', NULL, NULL, NULL),
(2, 'admin', 'Админ', '1,4,5,6,7,8,11,14,15,16,18,19,21,22,23', NULL, NULL, NULL),
(3, 'user', 'Личный кабинет', '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dnior_webapps_site_options_group`
--

CREATE TABLE IF NOT EXISTS `dnior_webapps_site_options_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name_ru` varchar(45) NOT NULL,
  `name_en` varchar(45) NOT NULL,
  `site_options_ids` text COMMENT 'Опции, относящиеся к группе',
  `ordering` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Группы опций' AUTO_INCREMENT=27 ;

--
-- Dumping data for table `dnior_webapps_site_options_group`
--

INSERT INTO `dnior_webapps_site_options_group` (`id`, `name_ru`, `name_en`, `site_options_ids`, `ordering`, `checked_out`, `checked_out_time`) VALUES
(25, 'Платежи онлайн', 'Online paynemt', '4,5,6,7,8', NULL, NULL, NULL),
(26, 'Социальные виджеты', 'Social widgets', '21,22,23,24', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dnior_webapps_site_options_partial`
--

CREATE TABLE IF NOT EXISTS `dnior_webapps_site_options_partial` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `site_option_id` int(11) unsigned NOT NULL,
  `sites_types_ids_location` text NOT NULL COMMENT 'id id типов сайтов, где опция пристуствует',
  `ordering` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `site_option_id` (`site_option_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Опции, присутствующие не на всех типах сайтов' AUTO_INCREMENT=9 ;

--
-- Dumping data for table `dnior_webapps_site_options_partial`
--

INSERT INTO `dnior_webapps_site_options_partial` (`id`, `site_option_id`, `sites_types_ids_location`, `ordering`, `checked_out`, `checked_out_time`) VALUES
(1, 1, '3', NULL, NULL, NULL),
(2, 2, '3', NULL, NULL, NULL),
(3, 3, '3', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dnior_webapps_site_types`
--

CREATE TABLE IF NOT EXISTS `dnior_webapps_site_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_ru` varchar(45) NOT NULL,
  `name_en` varchar(45) NOT NULL,
  `ordering` int(11) DEFAULT NULL,
  `checked_out` int(11) DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Типы сайтов	' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `dnior_webapps_site_types`
--

INSERT INTO `dnior_webapps_site_types` (`id`, `name_ru`, `name_en`, `ordering`, `checked_out`, `checked_out_time`) VALUES
(1, 'Корпоративный', 'Company', NULL, NULL, NULL),
(2, 'Личный', 'Private', NULL, NULL, NULL),
(3, 'Интернет-магазин', 'WebShop', NULL, NULL, NULL);
