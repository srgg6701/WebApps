CREATE TABLE IF NOT EXISTS `#__webapps_precustomers` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`ordering` INT(11)  NOT NULL ,
`state` TINYINT(1)  NOT NULL DEFAULT '1',
`checked_out` INT(11)  NOT NULL ,
`checked_out_time` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
`name` VARCHAR(45)  NOT NULL ,
`email` VARCHAR(45)  NOT NULL ,
`phone` VARCHAR(45)  NOT NULL ,
`collections_ids` TEXT NOT NULL ,
`skype` VARCHAR(45)  NOT NULL ,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT COLLATE=utf8_general_ci;

