<?php
/**
 * @version     1.4.0
 * @package     com_collector1
 * @copyright   Copyright (C) 2012. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt*/

// No direct access
defined('_JEXEC') or die;
//echo "<h3>MODEL: collector1.php</h3>";
/**
 * Model
 */
class DebugModelDebug extends JModel
{
}
