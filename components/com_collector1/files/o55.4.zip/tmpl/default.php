<?php

/*

Right side of the page is the file /components/com_content/view/stuff/temp/contacts.php

*/

/**
 * @package		Joomla.Site
 * @subpackage	mod_custom
 * @copyright	Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;
$querysent=JRequest::getVar('querysent');
$action=JRequest::getVar('action'); 
$object_profile=$modLeft3Helper->object_profile; var_dump("<h1>module:</h1><pre>",$module,"</pre>");?>
<script type="text/javascript">
function checkForm(obj_form){
	try{
		var mess='';
		var lst=obj_form.getElementById('title');
		if ( lst
			 && lst.options[lst.selectedIndex].value=='0'
		   ) {
			mess='\n* You have not selected a value from list "Title"';
			lst.focus();
		}
		var aFields=new Array('first_name','surname','email','phone','message','friend_email');
		for (i=0;i<aFields.length;i++){ //alert(aFields[i]);
			if ( obj_form.getElementById(aFields[i])
				&& ( !obj_form.getElementById(aFields[i]).value ||
					  obj_form.getElementById(aFields[i]).value=='0' ||
					  obj_form.getElementById(aFields[i]).value=='' ||
					  obj_form.getElementById(aFields[i]).value==' '
			   	   )
			   ) {
				 mess+='\n* You have not ';
				if (aFields[i]=='message') mess+='placed a message text!';
				else mess+='pointed a value for the field "'+aFields[i]+'"';
			}
			//else alert(obj_form.getElementById(aFields[i]).value);
		}
		if (mess!=''){
			alert('Error!'+mess);
			return false;
		}
	}catch(e){
		alert(e.message);
	}
}
</script>

<div id="contact_us">
    <div class="custom<?php echo $moduleclass_sfx ?>" <?php if ($params->get('backgroundimage')): ?> style="background-image:url(<?php echo $params->get('backgroundimage');?>)"<?php endif;?>>
        <?php echo $module->content;?>
    </div>
    
<? 
	?>
    <div class="message-box">
<? 	if($querysent == 1) {?>
        Thank you! Your query has been sent, we will contact you ASAP.
<? 	}elseif ($querysent == -1) {?>
		<span class="warning">Sorry, we couldn't send your messages because you <?
        if(JRequest::getVar('wrong_capcha')){
			?>pointed wrong captcha<?	}else{
			?>filled not all fields in the form<?
		}?>.
        <p>Please, be careful!</p>
        </span>
<? 	}?>    
    </div>
    <form method="post" id="contact-us" action="index.php?task=handle_user_mail" onSubmit="return checkForm(this);">
        <div class="form-item">
<?  if ($action=='email_to_friend'){?>  
    <div class="form-item">
      <label class="options" for="friend_email">
        Friend's e-mail:<span class="required"></span>
      </label>
      <input value="" type="text" name="friend_email" id="friend_email" maxlength="50" class="form-text required" />
    </div>
<?	}else{?>
      <label class="options" for="title">
        Title:<span class="required"></span>
      </label>
      <select name="title" id="title" class="form-select required">
        <option value="0">Please select</option>
	<? 	$aTitle=array('Mr.','Ms.','Miss.','Mrs.','Dr.','Other');
		for($i=0,$j=count($aTitle);$i<$j;$i++) {?>
        <option value="<?=$aTitle[$i]?>"<? if(JRequest::getVar('title')==$aTitle[$i]){?> selected<? }?>><?=$aTitle[$i]?></option>
      </select>
	<?	}?>
    	</div>
    
    <div class="form-item">
      <label class="options" for="first-name">
        First name:<span class="required"></span>
      </label>
      <input value="<?=JRequest::getVar('first_name');?>" type="text" name="first_name" id="first_name" maxlength="50" class="form-text required" />
    </div>
    
    <div class="form-item">
      <label class="options" for="surname">
        Surname:<span class="required"></span>
      </label>
      <input value="<?=JRequest::getVar('surname');?>" type="text" name="surname" id="surname" maxlength="50" class="form-text required" />
    </div>	                	  
    <div class="form-item">
      <label class="options" for="email">
        E-mail address:<span class="required"></span>
      </label>
      <input value="<?=JRequest::getVar('email');?>" type="text" name="email" id="email" maxlength="50" class="form-text required" />
    </div>
    
    <div class="form-item">
      <label class="options" for="phone">
        Telephone:<span class="required"></span>
      </label>
      <input value="<?=JRequest::getVar('phone');?>" type="text" name="phone" id="phone" maxlength="100" class="form-text required" />
<?	}?>    
    </div>
    <div class="form-item" id="textarea_block">
      <label class="options" for="message" style="margin-bottom:6px;">
        Message:<span class="required"></span>
<? 	if ($obj_id=JRequest::getVar('obj_id')):
		if($action!='email_to_friend') :?>
        <div style="width:240px; margin:4px 0 4px -1px; padding:10px; background:#FCC;border-radius:4px;">Please notice that a link for the object you've pointed <span style="color:#FF0000;">already is included into a message</span> <nobr>(between <b>&lt;a...&gt;&lt;/a&gt;</b> tag)</nobr>. Please, don't modify it in order to let us to get a right information.</div>
<? 		endif; 
	endif;?>
      </label>
      <textarea rows="10" cols="40" name="message" id="message" class="form-text"><?php
	  	if ($obj_id) {
			$pre_message="Hi!
";
			if ($action=='email_to_friend'){
				//get the address:
				
				$pre_message.="
------------------------
".$object_profile['address']."
";
			}else{
				$pre_message.="I am interested in the object id";?>?>
 <a href="http://www.w2lettings.com/index.php/sale?view=stuff&layout=profile&obj_id=<?=$obj_id?>"><?=$obj_id?></a>.<?
			} 
			echo $pre_message;
		}?></textarea>
    </div>
    <div class="form-submit">
<style>
input#osolCatchaTxt0{
	margin-top:6px;
}
img#captcha{
	/*width:216px;108px;*/
	/*height:80px;40px;*/
	border:solid 1px #CCCCCC;
	float:left;
	margin-right:8px;
}
div#captcha_field{
	margin-bottom:10px;
}
</style>
    <div id="captcha_field">
<?  switch ($_SERVER['HTTP_HOST'])  { 
    	case "localhost":
  	  		$host="/+frankandknights.com";
	    		break;
		case "96.125.164.153":
		  	$host="/~londong/frankandknights.com";
				break;
		//[default: www.frankandknights.com]
	}
	$img_path='http://'.$_SERVER['HTTP_HOST'].$host.'/components/com_content/securimage/';?> 
    	<img id="captcha" src="<?=$img_path?>securimage_show.php" alt="CAPTCHA Image" />
		<div style="margin-bottom:4px;">
			<a href="#" onclick="document.getElementById('captcha').src = '<?=$img_path?>securimage_show.php?' + Math.random(); return false">[ Different Image ]</a>
        </div>
    	<input type="text" name="captcha_code" size="10" maxlength="6" />
	</div>
        <input type="image" src="<?=$images_path?>submit.png" border="0" id="search"  value="submit" name="submit"/>
    </div> 
  	</form>
</div>    