<?php
/**
 * @package		Joomla.Site
 * @subpackage	mod_breadcrumbs
 * @copyright	Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;
class modLeft3Helper
{
	public $object_profile;
	/**
	 * Get object data, change module header, substitute the address
	 */
	function __construct(&$module,$obj_id){
		switch (JRequest::getVar('action')) {
			case 'email_to_friend':
				$module->title="Email to friend";	
				ContentHelperStuff::getSingleObjectProfile($obj_id);
				$this->object_profile=ContentHelperStuff::$arrSingleObjData;
			break;
		}
	}
}
