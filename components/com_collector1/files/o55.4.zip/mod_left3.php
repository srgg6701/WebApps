<?php
/**
 * @package		Joomla.Site
 * @subpackage	mod_custom
 * @copyright	Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;
JPluginHelper::importPlugin('content');
require_once JPATH_BASE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'stuff.php';
$module->content = JHtml::_('content.prepare', $module->content, '', 'mod_left3.content'); 
require_once dirname(__FILE__).DS.'helper.php';
$modLeft3Helper=new modLeft3Helper($module,JRequest::getVar('obj_id'));
$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));
$images_path='templates/lettings/images/';
require JModuleHelper::getLayoutPath('mod_left3', $params->get('layout', 'default'));
